/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dad_practica3.dto;

/**
 *
 * @author Anima
 */
public class Item {
    
    private String nombre;
    private String descripcion;
    private float precio;
    private int inventario;
    
    public Item(String nombre, String descripcion, float precio, int inventario) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.inventario = inventario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public int getInventario() {
        return inventario;
    }

    public void setInventario(int inventario) {
        this.inventario = inventario;
    }
    
    public String[] toArrayString() {
        String[] s = new String[4];
        s[0] = this.nombre;
        s[1] = this.descripcion;
        s[2] = String.valueOf(this.precio);
        s[3] = String.valueOf(this.inventario);
        return s;
    }
}
